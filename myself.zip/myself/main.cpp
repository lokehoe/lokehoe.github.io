#include <iostream>
#include <string>
#include <vector>
#include "OrderBookentry.h"
#include "Merkelmain.h"
#include "CSVReader.h"
#include "wallet.h"

int main()
{
    Merkelmain app{};
    app.init();
    
}